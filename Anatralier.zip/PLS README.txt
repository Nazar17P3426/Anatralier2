####################################
trojan: win32
os support: win xp
Malware: Anatralier
Gdi C+++
lucks lucks lucks
lucks lucks lucks
a virus compation trojan, this is good malware

          === By Hugopako ===